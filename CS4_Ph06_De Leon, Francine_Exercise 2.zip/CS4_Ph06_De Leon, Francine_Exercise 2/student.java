class Student {
    String name;
    String bday;
    int age;

    public Student(String name, String bday, int age) {
        this.name = name;
        this.bday = bday;
        this.age = age;
    }
}